# Desa Jaten - Template (Vite + React + Supabase)

Template ringan untuk Web Desa Jaten — cepat dideploy ke Cloudflare Pages dan terhubung ke Supabase (free tier).
Isi: form aspirasi/keluhan, tracking tiket, SOP, news, PWA.

## Cara pakai (singkat)
1. Install dependencies:
   ```
   npm install
   ```
2. Buat project Supabase, jalankan SQL di `supabase-migration.sql`.
3. Tambahkan environment variables (Cloudflare Pages / local .env):
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
4. Jalankan secara lokal:
   ```
   npm run dev
   ```
5. Deploy: build (`npm run build`) lalu deploy `dist` ke Cloudflare Pages.

## Build APK
Setelah `npm run build` Anda dapat membungkus PWA dengan Capacitor (lihat dokumentasi di project).
