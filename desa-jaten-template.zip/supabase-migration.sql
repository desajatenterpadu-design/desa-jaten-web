-- Supabase migration for Desa Jaten (run in Supabase SQL editor)
create extension if not exists "pgcrypto";

create table profiles (
  id uuid references auth.users on delete cascade,
  full_name text,
  nik text,
  rt text,
  rw text,
  role text default 'resident',
  created_at timestamptz default now(),
  primary key (id)
);

create table tickets (
  id uuid default gen_random_uuid() primary key,
  ticket_no text unique,
  user_id uuid references profiles(id),
  anon boolean default false,
  anon_name text,
  category text,
  subcategory text,
  description text,
  photo_path text,
  status text default 'submitted',
  priority text default 'normal',
  assigned_to uuid references profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  closed_at timestamptz
);

create table sops (
  id serial primary key,
  sector text,
  title text,
  summary text,
  file_path text,
  version text,
  published_at timestamptz default now()
);

create table news_posts (
  id serial primary key,
  title text,
  slug text unique,
  content text,
  author_id uuid references profiles(id),
  published_at timestamptz default now()
);

create table audit_logs (
  id serial primary key,
  user_id uuid,
  action text,
  model_type text,
  model_id text,
  ip_address text,
  user_agent text,
  created_at timestamptz default now()
);
