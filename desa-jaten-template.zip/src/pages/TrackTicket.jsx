import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function TrackTicket(){
  const [ticketNo, setTicketNo] = useState('')
  const [data, setData] = useState(null)

  const handleCheck = async (e) => {
    e.preventDefault()
    const { data: rows, error } = await supabase
      .from('tickets')
      .select('*')
      .eq('ticket_no', ticketNo)
      .limit(1)
    if (error) return alert(error.message)
    if (!rows || rows.length === 0) return alert('Tiket tidak ditemukan')
    setData(rows[0])
  }

  return (
    <div>
      <form onSubmit={handleCheck}>
        <input placeholder="Masukkan nomor tiket" value={ticketNo} onChange={e=>setTicketNo(e.target.value)} />
        <button>Cek</button>
      </form>
      {data && (
        <div>
          <h3>Ticket: {data.ticket_no}</h3>
          <p>Status: {data.status}</p>
          <p>Kategori: {data.category}</p>
          <p>Deskripsi: {data.description}</p>
        </div>
      )}
    </div>
  )
}
