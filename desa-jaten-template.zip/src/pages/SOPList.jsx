import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function SOPList(){
  const [sops, setSops] = useState([])

  useEffect(()=> {
    const load = async () => {
      const { data, error } = await supabase.from('sops').select('*').order('published_at', { ascending: false })
      if (!error) setSops(data || [])
    }
    load()
  },[])

  return (
    <div>
      {sops.length === 0 && <p>Belum ada SOP diunggah.</p>}
      {sops.map(s => (
        <div key={s.id}>
          <h4>{s.title} ({s.sector})</h4>
          <p>{s.summary}</p>
        </div>
      ))}
    </div>
  )
}
