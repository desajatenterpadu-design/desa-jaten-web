import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function NewsList(){
  const [news, setNews] = useState([])

  useEffect(()=> {
    const load = async () => {
      const { data, error } = await supabase.from('news_posts').select('*').order('published_at', { ascending: false })
      if (!error) setNews(data || [])
    }
    load()
  },[])

  return (
    <div>
      {news.length === 0 && <p>Belum ada berita.</p>}
      {news.map(n => (
        <article key={n.id}>
          <h4>{n.title}</h4>
          <div dangerouslySetInnerHTML={{__html: n.content}} />
        </article>
      ))}
    </div>
  )
}
