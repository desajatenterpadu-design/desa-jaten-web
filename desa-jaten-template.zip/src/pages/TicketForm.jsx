import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { v4 as uuidv4 } from 'uuid'

export default function TicketForm(){
  const [category, setCategory] = useState('')
  const [desc, setDesc] = useState('')
  const [file, setFile] = useState(null)
  const [anon, setAnon] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const ticketNo = 'JT-' + new Date().toISOString().replace(/[-:.TZ]/g,'').slice(0,14)
      let photoPath = null
      if (file) {
        const fileExt = file.name.split('.').pop()
        const fileName = `${uuidv4()}.${fileExt}`
        const { error: uploadErr } = await supabase.storage
          .from('tickets')
          .upload(fileName, file)
        if (uploadErr) throw uploadErr
        photoPath = fileName
      }

      const { error } = await supabase
        .from('tickets')
        .insert([{
          ticket_no: ticketNo,
          user_id: null,
          anon,
          anon_name: anon ? 'Anonim' : null,
          category,
          description: desc,
          photo_path: photoPath,
          status: 'submitted'
        }])

      if (error) throw error
      alert('Laporan terkirim. Nomor tiket: ' + ticketNo)
      setCategory(''); setDesc(''); setFile(null)
    } catch (err) {
      console.error(err)
      alert('Gagal kirim laporan: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="ticket-form">
      <label>Nama (opsional)</label>
      <input type="text" name="name" />

      <label>Kategori</label>
      <select value={category} onChange={e=>setCategory(e.target.value)} required>
        <option value="">--Pilih--</option>
        <option value="infrastruktur">Infrastruktur</option>
        <option value="sampah">Sampah & Lingkungan</option>
        <option value="kesehatan">Kesehatan</option>
        <option value="pelayanan">Pelayanan Publik</option>
      </select>

      <label>Deskripsi</label>
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} required />

      <label>Foto (opsional)</label>
      <input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])} />

      <label><input type="checkbox" checked={anon} onChange={e=>setAnon(e.target.checked)} /> Kirim anonim</label>

      <button type="submit" disabled={loading}>{loading ? 'Mengirim...' : 'Kirim Laporan'}</button>
    </form>
  )
}
