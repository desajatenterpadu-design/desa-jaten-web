import React from 'react'
import TicketForm from './pages/TicketForm'
import TrackTicket from './pages/TrackTicket'
import SOPList from './pages/SOPList'
import NewsList from './pages/NewsList'

export default function App(){
  return (
    <div className="app">
      <header className="header">
        <h1>Desa Jaten - Juwiring, Klaten</h1>
      </header>
      <main className="container">
        <section>
          <h2>Ajukan Aspirasi & Keluhan</h2>
          <TicketForm />
        </section>
        <section>
          <h2>Tracking Tiket</h2>
          <TrackTicket />
        </section>
        <section>
          <h2>SOP Pelayanan</h2>
          <SOPList />
        </section>
        <section>
          <h2>Berita & Pengumuman</h2>
          <NewsList />
        </section>
      </main>
      <footer className="footer">
        <small>© Pemerintah Desa Jaten - Juwiring, Klaten</small>
      </footer>
    </div>
  )
}
