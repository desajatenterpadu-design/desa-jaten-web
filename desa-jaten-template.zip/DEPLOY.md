# Deploy singkat ke Cloudflare Pages

1. Push repo ke GitHub.
2. Buat project di Cloudflare Pages -> connect GitHub repo.
3. Build command: `npm run build`
4. Build output directory: `dist`
5. Tambahkan environment variables di Pages:
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
6. Deploy dan kunjungi domain Pages.
